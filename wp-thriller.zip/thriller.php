<?php
/**
 * @package Thriller_Night
 * @author Derrick LeBrocq
 * @version 1.0
 */
/*
Plugin Name: Thriller Night
Plugin URI: http://www.simpweb.com
Description: This plugin is a tribute to the most influencial musician of all time, the KING OF POP, Michael Jackson. Love him or hate him, he was the THRILLER. This plugin signifies a generation of music that will never be matched again. It displays the lyrics for the hit single "Thriller", line at a time, in the upper right hand corner of the admin screen on every page.
Author: Derrick LeBrocq
Version: 1.0
Author URI: http://www.simpweb.com
*/

function thriller_get_lyric() {
	/** These are the lyrics to Thriller */
	$lyrics = "It's Close To Midnight 
And Something Evil's Lurking In The Dark 
Under The Moonlight You See A Sight 
That Almost Stops Your Heart 
You Try To Scream But 
Terror Takes The Sound Before You Make It 
You Start To Freeze 
As Horror Looks You Right Between The Eyes, 
You re Paralyzed 

Cause This Is Thriller, Thriller Night 
And No Ones Gonna Save You 
From The Beast About Strike 
You Know Its Thriller, Thriller Night 
You re Fighting For Your Life 
Inside A Killer, Thriller Tonight 

You Hear The Door Slam 
And Realize There's Nowhere Left To Run 
You Feel The Cold Hand 
And Wonder If You'll Ever See The Sun 
You Close Your Eyes 
And Hope That This Is Just Imagination 
But All The While 
You Hear The Creature Creepin Up Behind 
You re Out Of Time 

Cause This Is Thriller, Thriller Night 
There Aint No Second Chance 
Against The Thing With Forty Eyes 
You Know Its Thriller, Thriller Night 
You re Fighting For Your Life 
Inside Of Killer, Thriller Tonight 

They're Out To Get You, 
There's Demons Closing In On Every Side 
They Will Possess You 
Unless You Change The Number On Your Dial 
Now Is The Time For You And I
To Cuddle Close Together 
All Thru The Night 
I'll Save You From The Terror On The Screen, 
I'll Make You See 

That This Is Thriller, Thriller Night 
Cause I Can Thrill You 
More Than Any Ghost Would Dare To Try 
Girl, This Is Thriller, Thriller Night 
So Let Me Hold You Tight And Share A Killer, Diller, Chiller 
Thriller Here Tonight";

	// Here we split it into lines
	$lyrics = explode("\n", $lyrics);

	// And then randomly choose a line
	return wptexturize( $lyrics[ mt_rand(0, count($lyrics) - 1) ] );
}

// This just echoes the chosen line, we'll position it later
function thriller() {
	$chosen = thriller_get_lyric();
	echo "<p id='thriller'>$chosen</p>";
}

// Now we set that function up to execute when the admin_footer action is called
add_action('admin_footer', 'thriller');

// We need some CSS to position the paragraph
function thriller_css() {
	echo "
	<style type='text/css'>
	#thriller {
		position: absolute;
		top: 4.5em;
		margin: 0;
		padding: 0;
		right: 215px;
		font-size: 11px;
	}
	</style>
	";
}

add_action('admin_head', 'thriller_css');

?>
