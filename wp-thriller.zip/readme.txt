Plugin Name: Thriller Night
Plugin URI: http://www.simpweb.com

Description: This plugin is a tribute to the most influencial musician of all time, 
the KING OF POP, Michael Jackson. Love him or hate him, he was the THRILLER. 
This plugin signifies a generation of music that will never be matched again. 
It displays the lyrics for the hit single "Thriller", line at a time, in the upper 
right hand corner of the admin screen on every page.

Author: Derrick LeBrocq
Version: 1.0
Author URI: http://www.simpweb.com

